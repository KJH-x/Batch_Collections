import os
import sys
import shutil
import subprocess
from datetime import datetime

# 检查操作系统是否为 Windows
if os.name != 'nt':
    print("该程序仅支持 Windows 操作系统。")
    exit()

# 检查 Bandizip 命令行工具是否可用
bandizip_path = r'C:\Program Files\bandisoft\Bandizip\Bandizip.exe'  # Bandizip.exe 的路径
if not os.path.exists(bandizip_path):
    print("Bandizip 命令行工具未找到。请确保 Bandizip 安装路径正确。")
    exit()

# 获取当前脚本所在的目录
current_directory = os.path.dirname(os.path.abspath(sys.argv[0]))

# 源文件路径和目标文件夹路径
source_file = os.path.join(current_directory, "Campus_network.7z")
target_folder = os.path.join(current_directory, ".old")

# 检查源文件是否存在
if not os.path.exists(source_file):
    print("源文件 Campus_network.7z 不存在。")
else:
    # 创建目标文件夹（如果不存在）
    if not os.path.exists(target_folder):
        os.mkdir(target_folder)

    try:
        # 重命名源文件
        current_date = datetime.now().strftime("%y%m%d")
        new_file_name = f"Campus_network.{current_date}.7z"
        new_file_path = os.path.join(current_directory, new_file_name)
        os.rename(source_file, new_file_path)

        # 移动重命名后的文件到目标文件夹
        shutil.move(new_file_path, target_folder)

    except Exception as e:
        print(f"发生错误：{str(e)}")

# 获取文件所在文件夹路径
file_directory = os.path.dirname(source_file)

# 需要压缩的文件列表
file_list = ["AIO_login.py", "Network_Alive.ico", "Network_Alive.py",
             "Readme.md", "requirements.txt", "Tray_Launcher.pyw"]

# 补全文件路径
full_file_list = [os.path.join(file_directory, file) for file in file_list]

# 检查并排除不可读取的文件
excluded_files = []
for file_path in full_file_list:
    try:
        with open(file_path, 'rb'):
            pass
    except (IOError, OSError):
        excluded_files.append(file_path)

if excluded_files:
    print("以下文件不可读取，将被排除：")
    for file_path in excluded_files:
        print(file_path)

# 检查是否有正在被占用的文件
occupied_files = []
for file_path in full_file_list:
    try:
        with open(file_path, 'rb'):
            pass
    except IOError:
        occupied_files.append(file_path)

if occupied_files:
    print("以下文件正在被占用，无法进行压缩：")
    for file_path in occupied_files:
        print(file_path)
    exit()

compressed_file_path = os.path.join(current_directory, "Campus_network.7z")

# 压缩文件
command = [
    "bandizip.exe",
    'a',  # 添加文件到档案
    '-l:5',  # 设置压缩级别
    '-t:8',  # 设置CPU线程数
    # '-cmt:"Campus Network Files"',  # 设置ZIP文件注释
    f'{compressed_file_path}'  # 档案路径
] + full_file_list


try:
    subprocess.run(command, shell=True)
except Exception as e:
    print(f"发生错误：{str(e)}")
